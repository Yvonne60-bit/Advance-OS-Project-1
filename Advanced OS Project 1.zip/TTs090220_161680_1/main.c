#include<stdio.h>

int main() {

    int numberOfProcesses = 4; // Defining how many processes are running.

    float weightTime[numberOfProcesses];  // Defining array of weight time, array size  = number of processes
    float turnAroundTime[numberOfProcesses];   // Defining array of turnaround time, array size  = number of processes
    float averageWeightTime=0;   // Starting average weight time, defined 0 to start
    float averageTurnAroundTime=0;    // Starting turnaround time, defined 0 to start

    int i,j;  // extra variables needed for for loop

    float burstTime[] = {1, 2, 3, 4};    // Burst time of all the processes defined. Array size should be equal to number of process defined above.

    weightTime[0]=0;    //waiting time for first process is 0; it will start right away

    for(i=1;i<numberOfProcesses;i++) {
        weightTime[i] = 0;
        for ( j=0; j < i; j++) {
            weightTime[i] += burstTime[j];  //calculating wait time based on burst time
        }
    }

    printf("\nProcess\t\t        Burst Time\t\tWaiting Time\t     Turnaround Time");  // Fair print output in table format

    for(i=0; i < numberOfProcesses; i++) {
        turnAroundTime[i]= burstTime[i] + weightTime[i];            //calculating turnaround time
        averageWeightTime+=weightTime[i];                           //calculating turnaround time
        averageTurnAroundTime+=turnAroundTime[i];                   //calculating turnaround time
        printf("\nP[%d]\t\t\t%.2f\t\t\t%.2f\t\t\t%.2f",i+1, burstTime[i], weightTime[i], turnAroundTime[i]);
    }

    averageWeightTime/=i;      //calculating average
    averageTurnAroundTime/=i;  //calculating average


    printf("\n\nAverage Waiting Time:%.2f", averageWeightTime);   // Printing average
    printf("\nAverage Turnaround Time:%.2f", averageTurnAroundTime);    // Printing average

    return 0;
}